# pandas_mm
python ရဲ့ data analysis library တခုဖြစ်တဲ့ pandas ကို မြန်မာလိုလေ့လာနိုင်စေရန်အတွက် ရည်ရွယ်၍ပြုလုပ်ထားပါသည်။
